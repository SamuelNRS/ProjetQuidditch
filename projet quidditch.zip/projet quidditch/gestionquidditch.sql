-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1:3306
-- Généré le :  ven. 23 nov. 2018 à 13:38
-- Version du serveur :  5.7.23
-- Version de PHP :  7.2.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données :  `gestionquidditch`
--

-- --------------------------------------------------------

--
-- Structure de la table `joueur`
--

DROP TABLE IF EXISTS `joueur`;
CREATE TABLE IF NOT EXISTS `joueur` (
  `NumLicence` int(5) NOT NULL,
  `Nom` varchar(25) NOT NULL,
  `Prenom` varchar(50) NOT NULL,
  `DateNaissance` date DEFAULT NULL,
  `Taille` decimal(5,2) NOT NULL,
  `Poids` tinyint(4) DEFAULT NULL,
  `Statut` varchar(10) NOT NULL,
  `PostePrefere` varchar(15) DEFAULT NULL,
  `Photo` blob,
  PRIMARY KEY (`NumLicence`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `joueur`
--

INSERT INTO `joueur` (`NumLicence`, `Nom`, `Prenom`, `DateNaissance`, `Taille`, `Poids`, `Statut`, `PostePrefere`, `Photo`) VALUES
(45455, 'schiavi', '', '2018-11-13', '45.00', 45, 'fghgu', 'fghgu', 0x6667686775),
(334, 'schiavi', 'théo', '2018-10-30', '450.00', 45, 'fghgu', 'fghgu', 0x4e554c4c),
(44444, 'schiavi', 'NULL', '2018-11-06', '45.00', 45, 'Actif', 'fghgu', 0x7468c3a96f),
(44447, 'schiavi', '', '2018-11-14', '45.00', 45, 'fghgu', 'fghgu', 0x6667686775),
(45458, 'schiavi', '', '2018-11-06', '450.00', 55, 'fghgu', 'fghgu', 0x6667686775);

-- --------------------------------------------------------

--
-- Structure de la table `partciper`
--

DROP TABLE IF EXISTS `partciper`;
CREATE TABLE IF NOT EXISTS `partciper` (
  `NumLicence` int(5) NOT NULL,
  `Horaire` datetime NOT NULL,
  `Poste` varchar(15) NOT NULL,
  `Note` tinyint(4) DEFAULT NULL,
  `Titulaire` tinyint(1) NOT NULL,
  `Remplaçant` tinyint(1) NOT NULL,
  PRIMARY KEY (`NumLicence`,`Horaire`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `rencontre`
--

DROP TABLE IF EXISTS `rencontre`;
CREATE TABLE IF NOT EXISTS `rencontre` (
  `Horaire` datetime NOT NULL,
  `EquipeAdverse` varchar(50) NOT NULL,
  `LieuRencontre` varchar(50) NOT NULL,
  `NbPointsAdversaire` tinyint(4) NOT NULL,
  `NbNosPoints` tinyint(4) NOT NULL,
  PRIMARY KEY (`Horaire`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
